<?php
require APPPATH . 'core/API_Controller.php'; 
/**
* 
*/
class Users extends API_Controller
{
	
	function __construct()
	{
	   parent::__construct();
       $this->load->model('api/AuthModal', 'User');   
       // $this->load->helper('email');
       $this->load->helper('fileuploading');
	}

	function getProfile()
	{
       $coloum = 'id,first_name,last_name,full_name,email,country_code,phone,profile,country,state,city,pin,address,latitude,longitude,user_type,status,added_on,update_on,last_login,(select count(id) from orders where user_id="'.$this->login_user.'") "total_orders",(select count(id) from orders where user_id="'.$this->login_user.'") "total_paid_amount" ';
       $where  = "id ='".$this->login_user."' AND status !='3' ";
       $detail = $this->User->RowData('users',$coloum,$where);
       if($detail)
       {
          $where  = "user_id ='".$this->login_user."' AND status ='1' AND default_address='1' ";
          $coloum = 'id,country,state,city,address,pin,latitude,longitude,address_type';
       	  $address = $this->User->RowData('address',$coloum,$where);

       	  $detail->delivery_address= ($address)?$address:(object)array();
       	  $detail->payment_methods = $this->getpaymentMethods();
       	  $detail->profile_thumb   = ($detail->profile)?base_url('uploads/profile/thumb/'.$detail->profile):default_profile;
       	  $detail->profile         = ($detail->profile)?base_url('uploads/profile/'.$detail->profile):default_profile;
       	  
          $responce['profile'] = $detail;
          $responce['ac_deactivateoption'] = $this->acdeactivateOption('return');

          $res = array('status'=>'200','message'=>"Success",'record'=>$responce);

       }
       else
       {
         $res = array('status'=>'404','message'=>"detail not found"); 
       }
       $this->response($res);
	}

	function acdeactivateOption($type='')
	{
		$reson = array('Changing Careers',
	          'Too much notifications',
	          'My account was hacked',
	          'I have another Afri Grub account',
	          'I dint find proper value of Afri Grub',
	          'I don’t understand how to use Afri Grub',
	          'Other');
		if($type=='return')
		{
			return $reson;
		}
          $res = array('status'=>'200','message'=>"Success",'record'=>$reson);
          $this->response($res);

	}

	function updateprofile()
	{
	  $where  = "id ='".$this->login_user."' AND status !='3' ";
      $detail = $this->User->RowData('users','*',$where);
      if($detail)
      {
          $req = $this->input->post();
		  $pera = $this->PerameterValidation(array('first_name','last_name','country_code','phone','country',
		  	                                       'state','city','address','pin','latitude','longitude'),$req);

		  if(isset($req['remove_profile']) && $req['remove_profile'] =='1')
		  {
	        $profile = '';
	        if($detail->profile !='')
	        {
	          removeFile($detail->profile,$detail->profile);
	        }
		  }
		  else
		  {
		  	$old     = $detail->profile;
		  	$profile = UploadFile('profile','profile','thumb');
		  	if($profile !='')
		  	{
	          removeFile($detail->profile,$detail->profile);
		  		
		  	}
		  	else
		  	{
		  	 $profile = $old;
		  	}
		  }
		      $update['first_name']    = $pera['first_name'];
	          $update['last_name']     = $pera['last_name'];
	          $update['full_name']     = $pera['first_name'].' '.$pera['last_name'];
	          $update['country_code']  = $pera['country_code'];
	          $update['phone']         = $pera['phone'];
	          $update['country']       =  $pera['country'];
	          $update['state']         =  $pera['state'];
	          $update['city']          =  $pera['city'];
	          $update['pin']           =  $pera['pin'];
	          $update['address']       =  $pera['address'];
	          $update['latitude']      =  $pera['latitude'];
	          $update['longitude']     =  $pera['longitude'];
	          $update['profile']       =  $profile;
	          $update['added_on']     = now;
	          $update['update_on']    = now;
	          $query = $this->User->UpdateData('users',$update,$where);
	          if($query)
	          {
	          	 if(isset($req['delivery_address']))
		         {
		  	       $delivery_address = $this->PerameterValidation(array('country','state','city','address','pin','latitude','longitude'),$req['delivery_address']);
		  	       $delivery_address['default'] ='1';
		  	       $delivery_address['address_type']='1';

		  	       $this->addnewAddress($delivery_address);
		         }

		         //prepare proper responce 

                $this->getProfile();
	          }
	          else
	          {
	          	$res = array('status'=>'400','message'=>"Something went wrong");
	          }
      }
      else
      {
      	$res = array('status'=>'404','message'=>"detail not found");
      }


	 $this->response($res);
	}

	function getpaymentMethods()
	{
		return array();
	}

    function addnewAddress($address)
    {
      $where = array('user_id'=>$this->login_user); 
      $update['default_address'] = '0';
      $update['update_on']       = now;
	  $query = $this->User->UpdateData('address',$update,$where);

	  $insert['user_id']         =  $this->login_user;
	  $insert['country']         =  $address['country'];
	  $insert['state']           =  $address['state'];
	  $insert['city']            =  $address['city'];
	  $insert['pin']             =  $address['pin'];
	  $insert['address']         =  $address['address'];
	  $insert['latitude']        =  $address['latitude'];
	  $insert['longitude']       =  $address['latitude'];
	  $insert['added_on']        =  now;
	  $insert['update_on']       =  now;
      $insert['default_address'] = (isset($address['default']) && $address['default']=='1')?'1':'0';
      $insert['address_type']   = (isset($address['address_type']) && $address['address_type'])?$address['address_type']:'1';
      
      return  $query = $this->User->AddData('address',$insert);
    }
    
    function addAddress()
    {
	    $pera  = $this->PerameterValidation(array('country','state','city','pin','address','latitude','longitude','address_type','default'));
	    $address = $this->addnewAddress($pera);
	    if($address)
	    {
	    	$responce['id']           = strval($address);
	    	$responce['country']      = $pera['country'];
	    	$responce['state']        = $pera['state'];
	    	$responce['city']         = $pera['city'];
	    	$responce['address']      = $pera['address'];
	    	$responce['pin']          = $pera['pin'];
	    	$responce['latitude']     = $pera['latitude'];
	    	$responce['longitude']    = $pera['longitude'];
	    	$responce['address_type'] = $pera['address_type'];

	        $res = array('status'=>'200','message'=>'Success.','record'=>$responce);
	    }
	    else
	    {
	          $res = array('status'=>'400','message'=>'Something went wrong. Please try again');
	    }
        $this->response($res);


    }

    function changepassword()
    {
	    $pera  = $this->PerameterValidation(array('old_password','confirm_password'));
	    $data=$this->emptyValidation(array('old_password','confirm_password'));

	    $where = array('id'=>$this->login_user,'status !='=>'3');
	    $check = $this->User->RowData('users','*',$where);
	    if($check)
	    {
	      if($check->password == md5($pera['old_password']))
	      {  
	        $update['password']   = md5($pera['confirm_password']);
	        $update['update_on']  = now;
	        $query = $this->User->UpdateData('users',$update,$where);
	        if($query)
	        {
	          $res = array('status'=>'200','message'=>'Success.');
	        }
	        else
	        {
	          $res = array('status'=>'400','message'=>'Try again.');
	        }
	      }
	      else
	      {
	        $res = array('status'=>'400','message'=>'Current password mismatch');
	      }
	    }
	    else
	    {
	      $res = array('status'=>'404','message'=>'User detail not found');
	    }
        $this->response($res);
    }

    function deactiveAccount()
    {
    	$pera  = $this->PerameterValidation(array('reason_type','reason','password'));
	    $data  = $this->emptyValidation(array('reason_type','reason','password'));

    	$where = array('id'=>$this->login_user,'status !='=>'3');
	    $check = $this->User->RowData('users','*',$where);
	    if($check)
	    {
	    	if($check->password == md5($pera['password']))
	    	{
		    	$update['status']     = "3";
		        $update['update_on']  = now;
		        $query = $this->User->UpdateData('users',$update,array('id'=>$this->login_user));
		        if($query)
		        {
		         $insert['user_id']        =  $this->login_user;
			     $insert['reason']         =  $pera['reason'];
			     $insert['reason_type']    =  $pera['reason_type'];
			     $insert['added_on']       =  now;
			     $insert['update_on']      =  now;
		         $query = $this->User->AddData('deactivate_account',$insert);
		         if($query)
		         {
		         	$res = array('status'=>'200','message'=>'Success');
		         }
		         else
		         {
		           $res = array('status'=>'400','message'=>'Something went wrong. Please try again');
		         }
		        }
		        else
		        {
		         $res = array('status'=>'400','message'=>'Something went wrong. Please try again');	
		        }
	    	}
	    	else
	    	{
	    	$res = array('status'=>'400','message'=>'Incorrect password.');	
	    	}
	    }
	    else
	    {
	    	$res = array('status'=>'404','message'=>'User detail not found.');	
	    }

	    
         $this->response($res);
    }

    function becomeSeller()
    {
    	$req = $this->input->post();
    	$req['validation'] ="true";
        $pera = $this->PerameterValidation(array('user_type','business_name','pin','country','state','city','address','latitude','longitude'),$req);
        $data = $this->emptyValidation(array('user_type','business_name'));

    	$where = array('id'=>$this->login_user,'status !='=>'3');
	    $check = $this->User->RowData('users','*',$where);
	    if($check)
	    {
          if($check->user_type =='1')
          {
           $business_logo = UploadFile('business_logo','profile','thumb');
            
            $insert['seller_id']     =  $this->login_user;
            $insert['business_name'] =  $pera['business_name'];
            $insert['business_logo'] =  $business_logo;
            $insert['country']       =  $pera['country'];
            $insert['state']         =  $pera['state'];
            $insert['city']          =  $pera['city'];
            $insert['pin']           =  $pera['pin'];
            $insert['address']       =  $pera['address'];
            $insert['latitude']      =  $pera['latitude'];
            $insert['longitude']     =  $pera['longitude'];

            $query = $this->User->AddData('business_detail',$insert);

            $update['user_type']      =  $pera['user_type'];
            $update['business_name']  = $pera['business_name'];
            $update['admin_status']   = '0';
            $query = $this->User->UpdateData('users',$update,$where);
            if($query)
            {
	    	 $res = array('status'=>'200','message'=>'Seller account must be approved by Admin before user start to add products for sale.');	
            }
            else
            {
	    	 $res = array('status'=>'400','message'=>'Already register as a seller.');	
            }

          }
          else
          {
	    	$res = array('status'=>'400','message'=>'Already register as a seller.');	
          }
	    } 
	    else
	    {
	    	$res = array('status'=>'404','message'=>'User detail not found.');	
	    }
         $this->response($res);
	    
    }

}

?>