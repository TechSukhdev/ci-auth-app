<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 require APPPATH . 'core/Rest_Controller.php';
 
/**
    Created By Sukhdev Pawar (04-03-2021)
 * Controller for all User related  Operation like add , update detail etc..
 */ 

class Users extends Rest_Controller
{
  function __construct()
  {
    parent::__construct();
      $this->load->model('admin/AdminModal', 'User');   
      $this->load->helper('email');
      $this->load->helper('fileuploading');
  }

  function index()
  {
    echo "Not good";
  }
  
  function list()
  {

  }

  function detail()
  {

  }

  function changeStatus($user_id='',$status='')
  {
    $where = array('id'=>$user_id);
    $check = $this->User->RowData('users','*',$where);
    if($check)
    {
        $update['status']    = $status;
        $update['update_on'] = now;
        $query = $this->User->UpdateData('users',$update,$where);
        if($query)
        {
          $res = array('status'=>'200','message'=>'Success.');
        }
        else
        {
          $res = array('status'=>'400','message'=>'Try again.');
        }
    }
    else
    {
      $res= array('status'=>'404','message'=>USER_NOT_FOUND);      
    }
     $this->response($res);
  }

  function verifyStatus($user_id='',$status='0')
  {
    $where = array('id'=>$user_id);
    $check = $this->User->RowData('users','*',$where);
    if($check)
    {
        $update['admin_verify']  = $status;
        $update['update_on']     = now;
        $query = $this->User->UpdateData('users',$update,$where);
        if($query)
        {
          $res = array('status'=>'200','message'=>'Success.');
        }
        else
        {
          $res = array('status'=>'400','message'=>'Try again.');
        }
    }
    else
    {
      $res= array('status'=>'404','message'=>USER_NOT_FOUND);      
    }
     $this->response($res);
  }

  
  function changepassword()
  {
    $pera  = $this->PerameterValidation(array('user_id','old_password','confirm_password'));
    $data=$this->emptyValidation(array('user_id','old_password','confirm_password'));  
    $where = array('id'=>$pera['user_id'],'status !='=>'3');
    $check = $this->User->RowData('admin','*',$where);
    if($check)
    {
      if($check->password == md5($pera['old_password']))
      {  
        $update['password']   = md5($pera['confirm_password']);
        // $update['update_on']  = now;
        $query = $this->User->UpdateData('admin',$update,$where);
        if($query)
        {
          $res = array('status'=>'200','message'=>'Success.');
        }
        else
        {
          $res = array('status'=>'400','message'=>'Try again.');
        }
      }
      else
      {
        $res = array('status'=>'400','message'=>'Current password mismatch');
      }
    }
    else
    {
      $res = array('status'=>'404','message'=>'User detail not found');
    }

   
    
        

    $this->response($res);

  }

   function profileDetail($user_id='')
   {
     $where = array('id'=>$user_id,'status !='=>'3');
     $coloum = 
     $check = $this->User->RowData('users','*',$where);
     if($check)
     {
           $responce['id']            = $check->id;
           $responce['first_name']    = $check->first_name;
           $responce['last_name']     = $check->last_name;
           $responce['full_name']     = $check->full_name;
           $responce['email']         = $check->email;
           $responce['phone']         = $check->phone;
           $responce['added_on']      = $check->added_on;
           $responce['status']        = $check->status;
           $responce['last_login']    = $check->last_login;
           $responce['profile_thumb'] =($check->profile)?base_url('uploads/profile/thumb/'.$check->profile):defult_profile;
           $responce['profile_img'] =($check->profile)?base_url('uploads/profile/'.$check->profile):defult_profile;

        $res = array('status'=>'200','message'=>'Success.','record'=>$responce);
     }
     else
     {
       $res = array('status'=>'404','message'=>'User detail not found');
     }
     $this->response($res);
   }

   function updateProfile()
   {
      $req   = $this->input->post();
      $pera  = $this->PerameterValidation(array('user_id','full_name','phone'),$req);
      $data  = $this->emptyValidation(array('user_id'),$req);

      $where = array('id'=>$pera['user_id'],'status !='=>'3');
      $check = $this->User->RowData('admin','*',$where);
      if($check)
      {

          $uploaded_file = UploadFile('profile','profile','thumb');
          // /remove old file if uploaded/
          if($uploaded_file)
          {
            removeFile('uploads/profile/'.$check->profile,'uploads/profile/thumb/'.$check->profile);
          }

          $update['full_name']    = $pera['full_name'];
          $update['profile']       = ($uploaded_file)?$uploaded_file:$check->profile;
          $update['update_on']     = now;

          $query = $this->User->UpdateData('admin',$update,$where);
          if($query)
          {
             $responce['id']            = $check->id;
             $responce['full_name']     = $update['full_name'];
             $responce['added_on']      = $check->added_on;
             $responce['status']        = $check->status;
             $responce['last_login']    = $check->last_login;
             $responce['profile_thumb'] =($update['profile'])?base_url('uploads/profile/thumb/'.$update['profile']):defult_profile;
             $responce['profile_img'] =($update['profile'])?base_url('uploads/profile/'.$update['profile']):defult_profile;

            $res = array('status'=>'200','message'=>'Success.','record'=>$responce);

          }
          else
          {
              $res = array('status'=>'400','message'=>'Try again');
          }

      }
      else
      {
            $res = array('status'=>'404','message'=>'User detail not found');
      }
       $this->response($res);
   }


  
}
?>