<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 require APPPATH . 'core/Rest_Controller.php';
 
/**
    Created By Sukhdev Pawar (24-09-2019)
 * Controller for all Driver related  Operation like signin , signUp , update detail,Otp verify,changePassword, etc..
 */ 

class Auth extends Rest_Controller
{
  function __construct()
  {
    parent::__construct();
      $this->load->model('api/AuthModal', 'Auth');   
  }

  function index()
  {
    echo "Not good";
  }
  
  function signin()
  {
    $pera  = $this->PerameterValidation(array('email','password'));
    $data  = $this->emptyValidation(array('email','password'));  
    $where = array('email'=>$pera['email'],'status !='=>'3','user_type'=>'3');
    $check = $this->Auth->RowData('users','*',$where);
    
    if($check)
    {
       if($check->password ==  md5($pera['password']))
       {
         if($check->status == '1')
         {
           $responce['user_id']       = $check->id;
           $responce['full_name']     = $check->full_name;
           $responce['email']         = $check->email;
           $responce['status']        = $check->status;
           $responce['user_type']    = $this->getRole($check->user_type );
           $responce['last_login']    = ($check->last_login)?date('d-M-Y h:i a',intval($check->last_login)):'';
           $responce['profile_img']   = ($check->profile)?base_url('uploads/profile/'.$check->profile):default_profile;
          
           $payload=base64_encode(json_encode($responce));
           $token = $this->GetToken($payload);
           $this->addToken($token);
           header('authtoken:'.$token);

           // update last login 
            $update['last_login']  = now;
            $query = $this->Auth->UpdateData('users',$update,$where);

           $res = array('status'=>'200','message'=>'Success','record'=>$responce);
         }
         else
         {
          $res = array('status'=>'400','message'=>'Your account is blocked.');
         }
       }
       else
       {
        $res = array('status'=>'400','message'=>'Password mismatch');
       }
    }
    else
    {
      $res = array('status'=>'404','message'=>'User detail not found');
    }
    $this->response($res);

  }
   
  function getRole($role)
  {
    switch ($role) {
      case '1':
        return 'Super Admin';
        break;
      case '2':
        return 'Admin';
        break;
      
      default:
        return 'Super Admin';
        
        break;
    }
  }
  
  function forgotpassword()
  {
    $pera = $this->PerameterValidation(array('email'));
    $where = array('email'=>$pera['email'],'status !='=>'3');
    $check = $this->Auth->RowData('admin','*',$where);
    if($check)
    {
      // print_r($check);die();
      $otp    = rand(10000,99999);
      $expire = now;
      $sendmail  =  forgotpasswordMail($check->email,$check->full_name,$otp);
      if($sendmail)
      {
        $token = base64_encode(json_encode(array('user_id'=>$check->id,'token'=>now)));

        $update['forgot_pass_otp']        = $otp;
        $update['forgot_pass_otp_expire'] = $expire;
        $update['update_on']              = now;
        $update['forgot_pass_token']      = $token;
        $query = $this->Auth->UpdateData('admin',$update,$where);
        if($query)
         {
           $res=array('status'=>'200','message'=>'please check your email','record'=>array('token'=>$token));
         }
         else
         {
           $res=array('status'=>'400','message'=>'Something went wrong. Please try again');
         }
      }
      else
      {
        $res=array('status'=>'400','message'=>'Unable to send mail. Try again');
      } 
    }
    else
    {
      $res = array('status'=>'404','message'=>'Email not found.');
    }
    $this->response($res);
  }


  function resetPassword()
  {
    $pera = $this->PerameterValidation(array('token','password'));
    $where = array('forgot_pass_token'=>$pera['token']);
    $check = $this->Auth->RowData('admin','id,email,full_name,forgot_pass_otp',$where);
    if($check)
    {
      if($check->forgot_pass_otp=='verify')
      {
        $update['password'] = md5($pera['password']);
        $update['forgot_pass_otp'] = '';
        $update['forgot_pass_otp_expire'] = '';
        $update['update_on']      = now;
        $query = $this->Auth->UpdateData('admin',$update,$where);
         if($query)
         {
           $res=array('status'=>'200','message'=>'Success');
         }
         else
         {
           $res=array('status'=>'400','message'=>'Something went wrong. Please try again');
         }
      }
      else
      {
       $res=array('status'=>'404','message'=>'Verify otp which sent to your mail');
      }
    }
    else
    {
      $res=array('status'=>'404','message'=>'User detail not found.');
    }
     $this->response($res);

  }
}
?>