<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 require APPPATH . 'core/Rest_Controller.php';
 
/**
    Created By Sukhdev Pawar (04-03-2021)
 * Controller for all User related  Operation like add , update detail etc..
 */ 

class Vehicles extends Rest_Controller
{
  function __construct()
  {
    parent::__construct();
      $this->load->model('admin/AdminModal', 'Vehicle');   
      $this->load->helper('fileuploading');
  }

  function index()
  {
    echo "Not good";
  }
   // add edit comapny name from here
  function addCompany()
  {
    $req = $this->input->post();
    $req['test'] = '';
    $pera = $this->PerameterValidation(array('id','category','company_name','company_full_name','description'),$req);
    $data = $this->emptyValidation(array('company_name'),$req);

    $where = $pera['id']?array('id !='=>$pera['id']):array();
    $where['company_name']= $pera['company_name'];
    $check = $this->Vehicle->RowData('vehicle_companies','*',$where);
    if($check)
    {
      $res= array('status'=>'400','message'=>'Company already register');
      $this->response($res); 
    }
    $logo = UploadFile('logo','vehicles/company','thumb');
    $insert['category']     ='1';
    $insert['company_name'] =$pera['company_name'];
    $insert['company_full_name'] =$pera['company_full_name'];
    $insert['logo']        = $logo;
    $insert['description'] = $pera['description'];
    $insert['update_on'] = now;

    if($pera['id'])
    {
     $where = array('id'=>$pera['id']);
     $query = $this->Vehicle->UpdateData('vehicle_companies',$insert,$where);

    }
    else
    {
     $insert['added_on'] = now;
     $query = $this->Vehicle->addData('vehicle_companies',$insert);
    }

    if($query)
    {
      $res = array('status'=>'200','message'=>'Success.');
    }
    else
    {
      $res = array('status'=>'400','message'=>'Try again.');
    }

    $this->response($res);

  }
   // add edit vehicle name from here
  function add()
  {
    $req = $this->input->post();
    $req['test'] = '';
    $pera = $this->PerameterValidation(array('id','company_id','vehicle_name','vehicle_full_name','description'),$req);
    $data = $this->emptyValidation(array('vehicle_name','company_id'),$req);

    $where = $pera['id']?array('id !='=>$pera['id']):array();
    $where['vehicle_name']= $pera['vehicle_name'];
    $where['company_id']  = $pera['company_id'];
    $check = $this->Vehicle->RowData('vehicles','*',$where);
    if($check)
    {
      $res= array('status'=>'400','message'=>'Vehicle already register with this company');
      $this->response($res); 
    }
    $logo = UploadFile('logo','vehicles','thumb');
    $insert['company_id']     = $pera['company_id'];
    $insert['vehicle_name']   = $pera['vehicle_name'];
    $insert['vehicle_full_name'] =$pera['vehicle_full_name'];
    $insert['logo']        = $logo;
    $insert['description'] = $pera['description'];
    $insert['update_on'] = now;

    if($pera['id'])
    {
     $where = array('id'=>$pera['id']);
     $query = $this->Vehicle->UpdateData('vehicles',$insert,$where);

    }
    else
    {
     $insert['added_on'] = now;
     $query = $this->Vehicle->addData('vehicles',$insert);
    }

    if($query)
    {
      $res = array('status'=>'200','message'=>'Success.');
    }
    else
    {
      $res = array('status'=>'400','message'=>'Try again.');
    }

    $this->response($res);

  }

  function changeStatus($user_id='',$status='')
  {
    $where = array('id'=>$user_id);
    $check = $this->User->RowData('users','*',$where);
    if($check)
    {
        $update['status']    = $status;
        $update['update_on'] = now;
        $query = $this->User->UpdateData('users',$update,$where);
        if($query)
        {
          $res = array('status'=>'200','message'=>'Success.');
        }
        else
        {
          $res = array('status'=>'400','message'=>'Try again.');
        }
    }
    else
    {
      $res= array('status'=>'404','message'=>USER_NOT_FOUND);      
    }
     $this->response($res);
  }  
}
?>