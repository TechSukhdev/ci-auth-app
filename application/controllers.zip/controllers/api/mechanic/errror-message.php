403 for reenter the mobile number for login screen
405 for resend otp in case if your otp is get expire
406 = account verification is pending from admin
407 = document upload is pending
510 under development