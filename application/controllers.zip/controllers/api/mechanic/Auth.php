<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 require APPPATH . 'core/API_Controller.php';
 
/**
    Created By Sukhdev Pawar (24-02-2021)
 * Controller for all Auth related  Operation like signin , signUp , update detail,Otp verify,changePassword, etc..
 */ 

class Auth extends API_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('api/AuthModal', 'Auth');   
    $this->load->helper('fileuploading');
    $this->load->helper('messages');
  }

  function index()
  {
    echo "Not good";
  }
   
  function signup()
  {
    $pera = $this->PerameterValidation(array('name','country_code','phone','email','password','device_id','fcm_token','os_type','device_name','device_modal','timezone'));

    $pera['country_code'] ='+91';// set default country code for now
    $data = $this->emptyValidation(array('name','country_code','phone','email'));
    //check if phone already register with anouther user
    $where = "((country_code='".$pera['country_code']."' AND phone='".$pera['phone']."') || email='".$pera['email']."') && status !='3' && user_type='2' ";
    $check = $this->Auth->RowData('users','*',$where);
    if($check)
    {
      if($check->email_verify==1 && $check->mobile_verify==1 && $check->document_uploaded==1 && $check->admin_verify==0)
      {
         $res= array('status'=>'406','message'=>"Your account is under review. Please try again.");
      }
      else
      {
        // give already register message
        $res= array('status'=>'400','message'=>"Email or phone already taken.Please login");
      }
    }
    else
    {
        // register new user
      $insert['full_name']    = $pera['name'];
      $insert['email']        = $pera['email'];
      $insert['phone']        = $pera['phone'];
      $insert['country_code'] = $pera['country_code'];
      $insert['password']     = md5($pera['password']);
      $insert['md5']          = ($pera['password']);
      $insert['fcm_token']    = $pera['fcm_token'];
      $insert['device_id']    = $pera['device_id'];
      $insert['device_modal'] = $pera['device_modal'];
      $insert['device_name']  = $pera['device_name'];
      $insert['os_type']      = $pera['os_type'];
      $insert['user_type']    = 2;
      $insert['email_verify']   = 1;
      $insert['mobile_verify']  = 1;
      $insert['admin_verify']   = 0;
      $insert['document_uploaded']  = 0;

      $insert['added_on']       = now;
      $insert['update_on']      = now;

      $user =  $this->Auth->AddData('users',$insert);
      if($user)
      {
          $this->loginData($user);
      }
      else
      {
        $res= array('status'=>'400','message'=>SOMETHING_WRONG);
         $this->response($res);
      }
    }
      $this->response($res);

  }
 
  function signin()
  {
   $pera = $this->PerameterValidation(array('username','password','device_id','fcm_token','os_type','device_name','device_modal','timezone'));
    $data = $this->emptyValidation(array('username','password'));

   $where = array('email'=>$pera['username'],'user_type'=>'2','status !='=>3);
   $user = $this->Auth->RowData('users','*',$where);
   if($user)
   {
     if($user->password ==md5($pera['password']))
     {
     if($user->email_verify==1 && $user->mobile_verify==1 && $user->document_uploaded==1 && $user->admin_verify==0)
      {
         $res= array('status'=>'406','message'=>"Your account is under review. Please try again.");
      }
      else
      {
        // update detail
         $update['fcm_token']    = $pera['fcm_token'];
         $update['device_id']    = $pera['device_id'];
         $update['device_modal'] = $pera['device_modal'];
         $update['device_name']  = $pera['device_name'];
         $update['os_type']      = $pera['os_type'];
         $where  = array('id'=>$user->id); 
         $query  =  $this->Auth->UpdateData('users',$update,$where);
         $this->loginData($user->id,$user);   
      }
     }
     else{
        $res=array('status'=>'400','message'=>'Invalid credentials'); 
     }   
   }
   else
   {
    $res=array('status'=>'400','message'=>'Not register with us'); 
   }
   $this->response($res);
  }
  function loginData($user_id='',$user=null)
  {
    $where = array('id'=>$user_id);
    $user = ($user)?$user:$this->Auth->RowData('users','*',$where);
    if($user)
    {
      $data['id']           = $user->id;
      $data['full_name']    = $user->full_name?$user->id:'';
      $data['country_code'] = $user->country_code;
      $data['phone']        = $user->phone;
      $data['email']        = $user->email;
      $data['profile_thumb'] =$user->profile?base_url('uploads/profile/thumb/'.$user->profile):default_profile;
      $data['profile'] =$user->profile?base_url('uploads/profile/'.$user->profile):default_profile;
      
      // set auth token payload from here
      $payload['user_id']   =$data['id'];
      $payload['user_type'] ='1';
      $payload['full_name'] = $data['full_name'];
      $payload = base64_encode(json_encode($payload));
      $token   = $this->GetToken($payload);
      $this->addToken($token);
      header('authtoken:'.$token);
     

      if($user->document_uploaded==1)
        {
        $res=array('status'=>'200','message'=>'Successfuly login','record'=>$data); 
        }
        else
        {
          $res= array('status'=>'407','message'=>'Please upload the documents','record'=>$data); 
        }
         $res['token']  = $token;
    }
    else
    {
      $res= array('status'=>'404','message'=>USER_NOT_FOUND);
    }
      $this->response($res);
  }
  
  function uploadDocuments()
  {
    $req = $this->input->post();
    $req['test'] = '';
    $pera = $this->PerameterValidation(array('country','state','city','latitude','longitude','address'),$req);
    $data = $this->emptyValidation(array('country','city'),$req);
    // file validation 
    $errorMsg = '';
    if(!isset($_FILES['id_front']) && !isset($_FILES['driving_license_front']))
    {
      $res= array('status'=>'400','message'=>"Please upload id proof and driving license.");
    }
    else if(!isset($_FILES['id_front']))
    {
      $res= array('status'=>'400','message'=>"Please upload id proof.");
    }
    else if(!isset($_FILES['driving_license_front']))
    {
     $res= array('status'=>'400','message'=>"Please upload driving license.");
    }
    else
    {
      $path ='uploads/documents';
      $thumb='thumbs';
      $id_front = UploadFile('id_front',$path,$thumb);
      $id_back = UploadFile('id_back',$path,$thumb);
      $driving_license_front = UploadFile('driving_license_front',$path,$thumb);
      $driving_license_back  = UploadFile('driving_license_back',$path,$thumb);
      
      // mark inactive to last entry for selected user
      $where = array('user_id'=>$this->login_user,'status'=>'1');
      $update = array('status'=>'3','update_on'=>now);
      $this->Auth->UpdateData('mechanic_detail',$update,$where);

      $insert['user_id']             = $this->login_user;
      $insert['country']             = $pera['country'];
      $insert['state']               = $pera['state'];
      $insert['city']                = $pera['city'];
      $insert['address']             = $pera['address'];
      $insert['latitude']            = $pera['latitude'];
      $insert['longitude']           = $pera['longitude'];
      $insert['id_proof']            = "Id Proof";
      $insert['id_front']            = $id_front;
      $insert['id_back']             = $id_back;
      $insert['driving_license']      = "Driving License";
      $insert['driving_license_front'] = $driving_license_front;
      $insert['driving_license_back']  = $driving_license_back;
      $insert['update_on']  = now;
      $insert['added_on']   = now;
      $query =  $this->Auth->addData('mechanic_detail',$insert);
      if($query)
      {
       // update document status
        $where = array('id'=>$this->login_user);
        $update = array('document_uploaded'=>1,'update_on'=>now);
        $this->Auth->UpdateData('users',$update,$where);
        redirect('api/mechanic/Home');
      }
      else
      {
        $res= array('status'=>'400','message'=>SOMETHING_WRONG);
      }
    }
    $this->response($res);
  }

  function forgotPassword()
  {
    $pera = $this->PerameterValidation(array('username'));
    $data = $this->emptyValidation(array('username'));
    $where = array('email'=>$pera['username'],'user_type'=>'2','status !='=>3);
    $user = $this->Auth->RowData('users','*',$where);
    if($user)
    {
      $res= array('status'=>'200','message'=>"We have sent a reset link to your register email. please reset the password");
    }
    else
    {
      $res= array('status'=>'404','message'=>USER_NOT_FOUND);
    }
    $this->response($res);
  }
}
?>