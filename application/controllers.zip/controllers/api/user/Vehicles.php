<?php

defined('BASEPATH') OR exit('No direct script access allowed');
 require APPPATH . 'core/Rest_Controller.php';
 
/**
    Created By Sukhdev Pawar (04-03-2021)
 * Controller for all User related  Operation like add , update detail etc..
 */ 

class Vehicles extends Rest_Controller
{
  function __construct()
  {
    parent::__construct();
      $this->load->model('api/APIModal', 'Vehicle');   
      $this->load->helper('fileuploading');
  }

  function index()
  {
    echo "Not good";
  }
  
  function companies()
  {
    $where = array('status'=>'1');
    $records  = $this->Vehicle->GetData('vehicle_companies','*',$where);
    if($records)
    {
      foreach($records as $record)
      {
        $data['id'] =$record['id'];
        $data['company_name'] =$record['company_name'];
        $data['company_full_name'] =$record['company_full_name'];

        $data['logo_thumb'] =($record['logo'])?base_url('uploads/vehicles/company/thumb/'.$record['logo']):default_company_logo;
        $data['logo'] =($record['logo'])?base_url('uploads/vehicles/company/'.$record['logo']):default_company_logo;

        $data['description'] = $record['description'];
        $response[] =$data;
      }
      $res= array('status'=>'200','message'=>'Success','record'=>$response);
    }
    else
    {
      $res = DATA_NOT_FOUND;
    }
      $this->response($res);
  }

  function list($company_id='')
  {
    $where = $company_id?array('v.company_id'=>$company_id):array();
    $where['v.status'] ='1';
    $coloum = "v.*, vc.company_name, vc.company_full_name";
    $join[] = array('table'=>"vehicle_companies as vc","condition"=>"v.company_id=vc.id");
    $records  = $this->Vehicle->GetData('vehicles as v','*',$where,$join,'v.vehicle_name');
    if($records)
    {
      foreach($records as $record)
      {
        $data['id'] =$record['id'];
        $data['company_id'] =$record['company_id'];
        $data['company_name'] = $record['company_name'];
        $data['company_full_name'] =$record['company_full_name'];
        $data['vehicle_name'] =$record['vehicle_name'];
        $data['vehicle_full_name'] =$record['vehicle_full_name'];

        $data['logo_thumb'] =($record['logo'])?base_url('uploads/vehicles/thumb/'.$record['logo']):default_company_logo;
        $data['logo'] =($record['logo'])?base_url('uploads/vehicles/'.$record['logo']):default_company_logo;

        $data['description'] = $record['description'];
        $response[] =$data;
      }
      $res= array('status'=>'200','message'=>'Success','record'=>$response);
    }
    else
    {
      $res = DATA_NOT_FOUND;
    }
      $this->response($res);
  }

  function add()
  {
    $pera  = $this->PerameterValidation(array('company_id','vehicle_id','title','description','registration_no'));    
    $data  = $this->emptyValidation(array('vehicle_id','company_id','registration_no'));
    //check if this RC already register 
    $where = array('registration_no'=>$pera['registration_no']);
    $check = $this->Vehicle->RowData('user_vehicles','*',$where);
    if($check)
    {
      // update last one as a inactive
      $where = array('id'=>$check->id);
      $update['status']='2';
      $query = $this->Vehicle->UpdateData('user_vehicles',$update,$where);
    }

    $insert['user_id']     = $this->login_user;
    $insert['company_id']  = $pera['company_id'];
    $insert['vehicle_id']  = $pera['vehicle_id'];
    $insert['title']       = $pera['title'];
    $insert['description'] = $pera['description'];
    $insert['registration_no'] = $pera['registration_no'];
    $insert['added_on']  = now;
    $insert['update_on'] = now;
    $query = $this->Vehicle->addData('user_vehicles',$insert);
    if($query)
    {
      $res = array('status'=>'200','message'=>'Success.');
    }
    else
    {
      $res = array('status'=>'400','message'=>SOMETHING_WRONG);
    }

    $this->response($res);
  }

  function edit()
  {
    $pera  = $this->PerameterValidation(array('id','title','description','registration_no','status !='=>'3'));    
    $data  = $this->emptyValidation(array('id','registration_no'));
    $where = array('id'=>$pera['id']);
    $check = $this->Vehicle->RowData('user_vehicles','*',$where);
    if($check)
    {
    // $update['company_id']  = $pera['company_id'];
    // $update['vehicle_id']  = $pera['vehicle_id'];
     $update['title']       = $pera['title'];
     $update['description'] = $pera['description'];
     $update['registration_no'] = $pera['registration_no'];
     $update['update_on'] = now;
      $query = $this->Vehicle->UpdateData('user_vehicles',$update,$where);
      if($query)
      {
        $res = array('status'=>'200','message'=>'Successfully updated.');
      }
      else
      {
        $res = array('status'=>'400','message'=>SOMETHING_WRONG);
      }
    }
    else
    {
      $res = array('status'=>'404','message'=>"No such vehicle");      
    }
     $this->response($res);
  }

  function delete($id='')
  {
    $where = array('id'=>$id,'status !='=>'3');
    $check = $this->Vehicle->RowData('user_vehicles','*',$where);
    if($check)
    {
     $update['status']       = '3';
     $update['update_on'] = now;
      $query = $this->Vehicle->UpdateData('user_vehicles',$update,$where);
      if($query)
      {
        $res = array('status'=>'200','message'=>'Successfully deleted.');
      }
      else
      {
        $res = array('status'=>'400','message'=>SOMETHING_WRONG);
      }
    }
    else
    {
      $res = array('status'=>'404','message'=>"No such vehicle");      
    }
    $this->response($res);
  }

  function myVehicle()
  {
    $where['uv.status'] ='1';
    $coloum = "uv.*, vc.company_name, vc.company_full_name";
    $join[] = array('table'=>"vehicle_companies as vc","condition"=>"uv.company_id=vc.id");
    $records  = $this->Vehicle->GetData('user_vehicles as uv','*',$where,$join,'uv.title');
    $records = $records?$records:array();
     $res = array('status'=>'200','message'=>"Success",'record'=>$records);      
     $this->response($res);
  }


}
?>