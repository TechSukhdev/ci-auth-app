<?php

 require_once("APIModal.php");

/**
 * 
 */
class AuthModal extends APIModal
{
	
	
}
?>